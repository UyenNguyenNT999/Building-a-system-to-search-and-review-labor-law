const backendHOST = 'http://localhost:9101'

async function APIGetData(callback) {
    let endpoint = backendHOST + "/get-data";
    await fetch(endpoint, {
        method: "GET",
        headers: {
            'Content-Type': 'application/json'
        },
    })
    .then(r => r.json())
    .then(r => {
        if (callback) callback(true, r);
    })
    .catch(e => {
        if (callback) callback(false, e);
    });
};

async function APISearch(data,callback) {
    let endpoint = backendHOST + "/search?keywords=" + data;
    await fetch(endpoint, {
        method: "GET",
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(r => r.json())
    .then(r => {
        if (callback) callback(true, r);
    })
    .catch(e => {
        if (callback) callback(false, e);
    });
};

export {APIGetData, APISearch}