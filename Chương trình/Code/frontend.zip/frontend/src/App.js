import './App.css';
import { APIGetData, APISearch } from './APIs'
import React, { useState, useEffect } from "react";
import MaterialIcon, {colorPalette} from 'material-icons-react';

function App() {

	const [data, setData] = useState(null);
	const [result, setResult] = useState(null);
	const [isShowData, setIsShowData] = useState(true);
	const [isShowResult, setIsShowResult] = useState(false);

  useEffect(() => {
    APIGetData((success,response) => {
      if (success) setData(response.data);
    })
  }, []);

  const closeResult = (e) => {
    e.preventDefault();
    setIsShowResult(false);
    setIsShowData(true);
  }

  const onClickFind = (e) => {
    e.preventDefault();
    let input =  document.getElementById("input-search");
    setResult("Đang tải...");
    APISearch(input.value, (success, response) => {
      setIsShowData(false);
      setIsShowResult(true);
      if (success)
        setResult(response.data);
      else
        setResult("Có lỗi trong quá trình xử lý, vui lòng thử lại!");
    })
  }

  return (
    <div className="body"> 
      <div className='header-bar'>Hệ thống tìm kiếm & tra cứu luật lao động</div>
      <div className='search-bar'>
        <input id="input-search" className='text-field' type='text'/>
        <div className='button button-search' onClick={onClickFind}>Find</div>
      </div>
      {
        isShowData && data && 
        <div className='data-container'> 
          {Object.keys(data).map((law_name) => <DataItem data_name={law_name} data_value={data[law_name]}/>)}
        </div> 
      }
      {
          isShowResult &&
          <div className='result-container'>
            <div className='button button-close' onClick={closeResult}><MaterialIcon icon="close"/></div>
            {result}
          </div>
      }
    </div>
  );
}

function DataItem({data_name, data_value}) {

  const [showContent, setShowContent] = useState(false)
  const toggleShowContent = (e) => {
    e.preventDefault();
    setShowContent(!showContent);
  }
  return (
    <div className='data-item'> 
      <div className='header' onClick={toggleShowContent}>{data_name}</div>
      {showContent && <div className='container'>
        {data_value.map(row => <SubDataItem row={row}/>)}
      </div>}
    </div>
  )
}

function SubDataItem({row}) {
  const [showContent, setShowContent] = useState(false)
  const toggleShowContent = (e) => {
    e.preventDefault();
    setShowContent(!showContent);
  }
  return (
    <div className='sub-data-item'>
      <div className='header' onClick={toggleShowContent}>
        <div><b>{row.dieu_khoan_tuong_ung}</b>:{row.dinh_nghia}</div>
      </div>
      { showContent && <div className='container'>{row.noi_dung_chi_tiet}</div> }
    </div>
  )
}

export default App;
